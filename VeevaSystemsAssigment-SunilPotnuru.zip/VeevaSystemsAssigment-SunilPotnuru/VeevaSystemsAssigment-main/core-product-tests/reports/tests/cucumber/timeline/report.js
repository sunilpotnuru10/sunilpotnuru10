$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"c78335cd-3f7a-456e-a60d-a3e76aa3cd84","feature":"Test CoreProduct HomePage","scenario":"Count Videos Feeds in Homepage","start":1738841808016,"group":29,"content":"","tags":"","end":1738841815674,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":29,"content":"Thread[#29,TestNG-PoolService-1,5,main]"}]);
});