# Veeva Technical Assessment - Test Automation Framework

This project contains the Test Automation framework for three products:  
- **Core Product (CP)**  
- **Derived Product 1 (DP1)**  
- **Derived Product 2 (DP2)**  

A total of four test scenarios are automated using **Selenium, Java, TestNG, and Cucumber BDD**.

## 📂 Framework Structure

The project is modularized into four main components:

1. **automation-framework** - Contains reusable utilities, drivers, and common functions.  
2. **core-product-tests** - Test scripts and feature files specific to the Core Product.  
3. **derived-product1-tests** - Test scripts and feature files for Derived Product 1.  
4. **derived-product2-tests** - Test scripts and feature files for Derived Product 2.  

Each test module depends on `automation-framework` for common functionalities.

## 🛠 Installation & Setup

### Prerequisites  
Ensure you have the following installed:
- **Java 11 or later**  
- **Maven** (`mvn -version` to verify)  
- **IDE** (IntelliJ IDEA, Eclipse, or VS Code)  
- **Google Chrome & ChromeDriver** (Ensure compatibility)  

### Steps to Set Up  
1. Clone this repository:  
   ```sh
   git clone <repo-url>
   cd VeevaSystemsAssigment-main
   ```
2. Import as a **Maven Project** in your IDE.  
3. Run `mvn clean install` to resolve dependencies.  

## ▶️ Test Execution

### Run All Tests (via Maven)  
```sh
mvn test
```

### Run Specific Feature File  
```sh
mvn test -Dcucumber.options="src/test/resources/features/<feature-file>.feature"
```

### Run Tests Using TestNG XML  
```sh
mvn test -DsuiteXmlFile=testng.xml
```

## 📊 Test Reports

**Extent Reports** are generated after execution. You can find them here:  
```
target/extent-reports/ExtentReport.html
```
To view the report, open the `.html` file in a browser.

## 🛠 Technologies Used

- **Java** (Test Automation)  
- **Selenium WebDriver** (Browser automation)  
- **TestNG** (Test execution & assertions)  
- **Cucumber BDD** (Behavior-driven development)  
- **Maven** (Dependency management)  
- **Extent Reports** (Test reporting)  

## 🤝 Contribution

If you wish to contribute, fork the repository and submit a pull request.

---

### 📧 Contact  
For any queries, reach out via email or the repository issues section.
